const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const convertPdf = require("pdf-poppler"); //<<causing linus is NOT supported error

const router = express.Router();
const MulterAzureStorage = require("multer-azure-blob-storage").MulterAzureStorage;
const azureStorage = new MulterAzureStorage({
  connectionString: process.env.connectionString,
  accessKey: process.env.accessKey,
  accountName: process.env.accountName,
  containerName: process.env.containerName,
  containerAccessLevel: 'blob',
  urlExpirationTime: 60
})
const upload = multer({
  storage: azureStorage
})
// const s3 = new aws.S3({
//   accessKeyId: process.env.ACCESSKEY,
//   secretAccessKey: process.env.SECRETACCESS,
//   Bucket: process.env.BUCKET
// });

// const singleImgUpload = multer({
//   storage: multerS3({
//     s3: s3,
//     bucket: process.env.BUCKET,
//     acl: "public-read",
//     key: function(req, file, cb) {
//       cb(
//         null,
//         path.basename(file.originalname, path.extname(file.originalname)) +
//           "-" +
//           Date.now() +
//           path.extname(file.originalname)
//       );
//     }
//   }),

//   limits: { fileSize: 2000000 }, // In bytes: 2000000 bytes = 2mb max file size
//   fileFilter: function(req, file, cb) {
//     checkFileType(file, cb);
//   }
// }).single("image");

function checkFileType(file, cb) {
  // allowed file types
  const filetypes = /jpeg|jpg|png|gif/;
  const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
  const mimetype = filetypes.test(file.mimetype); // using regex to check file ext

  if (mimetype && extname) {
    // checking if file is a valid image
    return cb(null, true);
  } else {
    cb("Error: Images Only!");
  }
}

// const storage = multer.diskStorage({
//   destination: function(req, file, cb) {
//     cb(null, path.join(__dirname, "/uploads/"));
//   },
//   filename: function(req, file, cb) {
//     // let pdfName = "samplePDF";
//     // req.body.file = pdfName;
//     cb(null, file.originalname);
//   }
// });

router.post("/pdf", upload.any(), (req, res, next) => {
  const uploadPath = req.file.path;
  var imagePath =
    req.file.destination + req.file.originalname.slice(0, -4) + "-1.jpg";
  let opts = {
    format: "jpg",
    out_dir: req.file.destination,
    out_prefix: path.basename(req.file.path).slice(0, -4),
    page: null
  };
  var pdfTojpg = convertPdf.convert(uploadPath, opts).then((pdfinfo) => {
    console.log(pdfinfo);
  });

  pdfTojpg.catch((err) => {
    console.error(err);
  });
  pdfTojpg.then(() => {
    fs.readFile(imagePath, (err, data) => {
      console.log(data);
      if (err) throw err;
      const params = {
        Bucket: process.env.BUCKET,
        Key: path.basename(imagePath),
        Body: data,
        ACL: "public-read"
      };
      s3.upload(params, (s3Error, data) => {
        if (s3Error) throw s3Error;
        console.log(data);
        console.log(`File uploaded successfully at ${data.Location}`);
        res.json({
          image: data.key,
          location: data.Location
        });
      });
    });
  });
});
router.post("/jpg", (req, res) => {
  singleImgUpload(req, res, (error) => {
    if (error) {
      console.log("errors", error);
      res.json({ error: error });
    } else {
      if (req.file === undefined) {
        console.log("Error: No File Selected");
        res.json("Error: No File Selected");
      }

      const jpgName = req.file.key;
      const jpgLocation = req.file.location;

      res.json({
        jpg: jpgName,
        location: jpgLocation
      });
    }
  });
});
router.post("/upload", upload.any(), (req, res) => {


  res.status(200).json(req.files["0"].url)
});

module.exports = router;
