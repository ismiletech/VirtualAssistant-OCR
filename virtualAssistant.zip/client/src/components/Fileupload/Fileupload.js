import React, { Component } from 'react';
const 
export default class Fileupload extends Component {
    render(){
        return (
            <div class="fileupload">
                
            </div>
        );
    }

}