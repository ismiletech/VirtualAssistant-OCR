
# VirtualAssitant-OCR<br>
### Recognize printed and handwritten text using Azure Cognitive Services<br>


### Instructions to run demo:<br>
* make an environment variables called ```ACCESSKEY```, ```REACT_APP_OCRKEY```, ```SECRETACCESS``` and give it the values of your subscription key from Azure Computer Vision Api
* Run ```npm install```
* Run ```node get-printed-text.js```
* MUST DISABLE CORS POLICY FOR APP TO WORK!!!
